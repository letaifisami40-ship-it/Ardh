package Com.ardhi.farm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private enum class Lang(val code:String,val native:String){ AR("ar","العربية"),FR("fr","Français"),EN("en","English"),IT("it","Italiano"),ES("es","Español"),SW("sw","Kiswahili") }
private enum class Role(val key:String,val ar:String){ PERSON("person","شخص"),FARMER("farmer","مزارع"),EQUIPMENT_OWNER("equipment_owner","مالك معدات"),PROFESSIONAL("professional","مهني زراعي"),COMPANY("company","شركة / مؤسسة"),ACCOUNTANT("accountant","محاسب"),OWNER("owner","مالك التطبيق") }
private enum class Page { HOME,FARMS,FIELDS,AGRI,FERTILIZER,EQUIPMENT,SERVICES,BOOKINGS,INVOICES,ACCOUNTING,SUBSCRIPTIONS,OWNER,DOCUMENTS,REPORTS,SETTINGS }

data class RowData(val id:String,val data:Map<String,Any?>)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);FirebaseApp.initializeApp(this);setContent{ArdhiApp()}}
}

@Composable fun ArdhiApp(){
 val context=LocalContext.current; val auth=remember{FirebaseAuth.getInstance()}; val db=remember{FirebaseFirestore.getInstance()};
 var lang by remember{mutableStateOf(loadLang(context))}; var user by remember{mutableStateOf(auth.currentUser)}; var role by remember{mutableStateOf(Role.PERSON)}
 LaunchedEffect(user){ if(user!=null){role=loadRole(db,user!!.uid)}}
 if(user==null){AuthPage(lang,{lang=it;saveLang(context,it)},auth,db){u,r->user=u;role=r};return}
 CompositionLocalProvider(LocalLayoutDirection provides if(lang==Lang.AR)LayoutDirection.Rtl else LayoutDirection.Ltr){
  MainShell(context,lang,{lang=it;saveLang(context,it)},auth,db,user!!,role,{auth.signOut();user=null}, {role=loadRole(db,user!!.uid)})
 }
}

private fun loadLang(c:Context):Lang{val v=c.getSharedPreferences("ardhi",0).getString("lang",null);return v?.let{s->Lang.values().firstOrNull{it.code==s}}?:when(Locale.getDefault().language){"fr"->Lang.FR;"en"->Lang.EN;"it"->Lang.IT;"es"->Lang.ES;"sw"->Lang.SW;else->Lang.AR}}
private fun saveLang(c:Context,l:Lang){c.getSharedPreferences("ardhi",0).edit().putString("lang",l.code).apply()}
private suspend fun loadRole(db:FirebaseFirestore,uid:String):Role{val s=db.collection("users").document(uid).get().await();return Role.values().firstOrNull{it.key==s.getString("role")}?:Role.PERSON}
private fun txt(l:Lang,ar:String,fr:String,en:String,it:String= en,es:String=en,sw:String=en)=when(l){Lang.AR->ar;Lang.FR->fr;Lang.EN->en;Lang.IT->it;Lang.ES->es;Lang.SW->sw}

@Composable private fun AuthPage(lang:Lang,onLang:(Lang)->Unit,auth:FirebaseAuth,db:FirebaseFirestore,onSuccess:(FirebaseUser,Role)->Unit){
 var register by remember{mutableStateOf(true)};var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var name by remember{mutableStateOf("")};var role by remember{mutableStateOf(Role.PERSON)};var err by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text("أرضي – Ardhi Farm",style=MaterialTheme.typography.headlineMedium);Text(txt(lang,"منصة الزراعة والأعمال والحسابات","Plateforme agricole et comptable","Agriculture, business and accounting platform"))
  Text("اللغة");Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){Lang.values().forEach{l->FilterChip(lang==l,{onLang(l)},label={Text(l.native)})}}
  OutlinedTextField(name,{name=it},label={Text(txt(lang,"الاسم","Nom","Name"))},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(password,{password=it},label={Text(txt(lang,"كلمة المرور","Mot de passe","Password"))},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
  if(register){Text(txt(lang,"نوع الحساب","Type de compte","Account type"));LazyColumn(Modifier.height(170.dp)){items(Role.values().filter{it!=Role.OWNER}){r->FilterChip(role==r,{role=r},label={Text(r.ar)},modifier=Modifier.padding(2.dp))}}}
  Button(enabled=!busy,onClick={
   if(!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()||password.length<6){err=txt(lang,"تحقق من البريد وكلمة المرور (6 أحرف على الأقل)","Vérifiez l'e-mail et le mot de passe (6 caractères min.)","Check email and password (6+ characters)");return@Button}
   busy=true;err="";scope.launch{try{val res=if(register)auth.createUserWithEmailAndPassword(email.trim(),password).await() else auth.signInWithEmailAndPassword(email.trim(),password).await();val u=res.user!!;val existing=db.collection("users").document(u.uid).get().await();val saved=Role.values().firstOrNull{it.key==existing.getString("role")}?:role;db.collection("users").document(u.uid).set(mapOf("uid" to u.uid,"email" to (u.email?:email.trim()),"name" to name,"role" to saved.key,"status" to if(register)"free" else (existing.getString("status")?:"free"),"language" to lang.code,"createdAt" to (existing.getLong("createdAt")?:System.currentTimeMillis()),"updatedAt" to System.currentTimeMillis())).await();audit(db,u.uid,"auth_${if(register)"register" else "login"}",mapOf("role" to saved.key));onSuccess(u,saved)}catch(e:Exception){err=e.message?:"Error"}finally{busy=false}}
  }){Text(if(register)txt(lang,"إنشاء الحساب","Créer le compte","Create account") else txt(lang,"دخول","Connexion","Sign in"))}
  TextButton({register=!register}){Text(if(register)txt(lang,"لدي حساب بالفعل","J'ai déjà un compte","I already have an account") else txt(lang,"إنشاء حساب جديد","Créer un compte","Create account"))}
  if(err.isNotBlank())Text(err,color=MaterialTheme.colorScheme.error)
 }
}

@Composable private fun MainShell(context:Context,lang:Lang,onLang:(Lang)->Unit,auth:FirebaseAuth,db:FirebaseFirestore,user:FirebaseUser,role:Role,onLogout:()->Unit,onReloadRole:()->Unit){
 var page by remember{mutableStateOf(Page.HOME)}
 val pages=if(role==Role.OWNER) listOf(Page.HOME,Page.FARMS,Page.EQUIPMENT,Page.INVOICES,Page.ACCOUNTING,Page.OWNER,Page.SETTINGS) else listOf(Page.HOME,Page.FARMS,Page.EQUIPMENT,Page.INVOICES,Page.ACCOUNTING,Page.SETTINGS)
 Scaffold(topBar={TopAppBar(title={Text("أرضي – Ardhi Farm")},actions={Text(role.ar,modifier=Modifier.padding(end=12.dp))})},bottomBar={NavigationBar{pages.take(5).forEach{p->NavigationBarItem(page==p,{page=p},icon={Text("•")},label={Text(pageName(lang,p))})}}}){pad->
 Column(Modifier.padding(pad).fillMaxSize()){
  when(page){
   Page.HOME->HomePage(lang,db,user,role,{page=it})
   Page.FARMS->FarmsPage(lang,db,user.uid)
   Page.FIELDS->FieldsPage(lang,db,user.uid)
   Page.AGRI->AgriculturePage(lang,db,user.uid)
   Page.FERTILIZER->FertilizerPage(lang,db,user.uid)
   Page.EQUIPMENT->EquipmentPage(lang,db,user.uid)
   Page.SERVICES->ServicesPage(lang,db,user.uid,role)
   Page.BOOKINGS->BookingsPage(lang,db,user.uid,role)
   Page.INVOICES->InvoicesPage(lang,db,user.uid)
   Page.ACCOUNTING->AccountingPage(lang,db,user.uid)
   Page.SUBSCRIPTIONS->SubscriptionsPage(lang,db,user.uid,role)
   Page.OWNER->OwnerPage(lang,db)
   Page.DOCUMENTS->DocumentsPage(lang,db,user.uid)
   Page.REPORTS->ReportsPage(context,lang,db,user.uid)
   Page.SETTINGS->SettingsPage(context,lang,onLang,onLogout,onReloadRole)
  }
 }
}}
private fun pageName(l:Lang,p:Page)=when(p){Page.HOME->txt(l,"الرئيسية","Accueil","Home");Page.FARMS->txt(l,"المزارع","Fermes","Farms");Page.EQUIPMENT->txt(l,"المعدات","Équipements","Equipment");Page.INVOICES->txt(l,"الفواتير","Factures","Invoices");Page.ACCOUNTING->txt(l,"الحسابات","Comptabilité","Accounting");else->p.name}

@Composable private fun HomePage(l:Lang,db:FirebaseFirestore,user:FirebaseUser,role:Role,go:(Page)->Unit){
 LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(txt(l,"مرحباً بك في أرضي","Bienvenue sur Ardhi","Welcome to Ardhi"),style=MaterialTheme.typography.headlineSmall);Text("${user.email} — ${role.ar}")}
 val cards=listOf(Triple(Page.FARMS,"المزارع والحقول","المزارع، الحقول، المحاصيل والعمليات"),Triple(Page.FIELDS,"الحقول","حقول ومحاصيل وتربة وري"),Triple(Page.AGRI,"العمليات الزراعية","نشاط، تاريخ، كمية ووحدة"),Triple(Page.FERTILIZER,"حاسبة الأسمدة","حسابات حسب المساحة والوحدة"),Triple(Page.EQUIPMENT,"معداتي","معدات وأسعار خدمات يحددها المالك"),Triple(Page.SERVICES,"الخدمات والحجوزات","طلبات، قبول، تنفيذ ومواعيد"),Triple(Page.BOOKINGS,"مواعيدي","حجوزات وحالة التنفيذ"),Triple(Page.INVOICES,"الفواتير","فواتير وحالات الدفع وPDF"),Triple(Page.ACCOUNTING,"المحاسبة","إيرادات، مصروفات، أرصدة وتقارير"),Triple(Page.SUBSCRIPTIONS,"الاشتراكات","مجاني، مدفوع، نشط، منتهٍ"),Triple(Page.DOCUMENTS,"المستندات والمسح","التقاط/اختيار صورة واستخراج نص مع مراجعة"),Triple(Page.REPORTS,"التقارير","تقارير مالية وزراعية"));items(cards){(p,t,b)->Card(Modifier.fillMaxWidth(),onClick={go(p)}){Column(Modifier.padding(16.dp)){Text(t,style=MaterialTheme.typography.titleLarge);Text(b)}}};if(role==Role.OWNER)item{Card(Modifier.fillMaxWidth(),onClick={go(Page.OWNER)}){Column(Modifier.padding(16.dp)){Text("لوحة مالك التطبيق",style=MaterialTheme.typography.titleLarge);Text("المستخدمون، الاشتراكات، الإيرادات والحسابات البنكية للمالك")}}}}
}

@Composable private fun FarmsPage(l:Lang,db:FirebaseFirestore,uid:String){
 CrudPage(l,"المزارع",db,"farms",uid,listOf("name","area","unit","crop","notes"),"إضافة مزرعة")
}
@Composable private fun FieldsPage(l:Lang,db:FirebaseFirestore,uid:String){CrudPage(l,"الحقول",db,"fields",uid,listOf("farmId","name","area","unit","crop","soil","irrigation"),"إضافة حقل")}
@Composable private fun AgriculturePage(l:Lang,db:FirebaseFirestore,uid:String){CrudPage(l,"العمليات الزراعية",db,"activities",uid,listOf("fieldId","type","date","quantity","unit","notes"),"إضافة عملية")}

@Composable private fun FertilizerPage(l:Lang,db:FirebaseFirestore,uid:String){
 var area by remember{mutableStateOf("")};var areaUnit by remember{mutableStateOf("ha")};var rate by remember{mutableStateOf("")};var rateUnit by remember{mutableStateOf("kg/ha")};var result by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("حاسبة الأسمدة المتقدمة",style=MaterialTheme.typography.headlineSmall);Text("تُحسب الكمية ولا تخلط بين m² وha. راجع الجرعة الزراعية قبل التطبيق.")
  OutlinedTextField(area,{area=it},label={Text("المساحة")},modifier=Modifier.fillMaxWidth());Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(areaUnit=="m²",{areaUnit="m²"},label={Text("m²")});FilterChip(areaUnit=="ha",{areaUnit="ha"},label={Text("ha")})}
  OutlinedTextField(rate,{rate=it},label={Text("معدل السماد")},modifier=Modifier.fillMaxWidth());Text("الوحدة: $rateUnit")
  Button(onClick={val a=area.toDoubleOrNull()?:0.0;val r=rate.toDoubleOrNull()?:0.0;val ha=if(areaUnit=="m²")a/10000 else a;val kg=ha*r;result="الكمية التقريبية: %.2f kg".format(kg);scope.launch{db.collection("fertilizer_calculations").add(mapOf("userId" to uid,"area" to a,"areaUnit" to areaUnit,"rate" to r,"rateUnit" to rateUnit,"resultKg" to kg,"createdAt" to System.currentTimeMillis())).await()}}){Text("احسب واحفظ")};if(result.isNotBlank())Text(result,style=MaterialTheme.typography.titleMedium)}
}

@Composable private fun EquipmentPage(l:Lang,db:FirebaseFirestore,uid:String){CrudPage(l,"معداتي",db,"equipment",uid,listOf("type","name","brand","model","year","power","identifier","condition","servicePrice","priceUnit","photoNote"),"إضافة معدة")}
@Composable private fun ServicesPage(l:Lang,db:FirebaseFirestore,uid:String,role:Role){CrudPage(l,"خدمات المعدات",db,"services",uid,listOf("equipmentId","service","price","priceUnit","location","notes"),"إضافة خدمة")}
@Composable private fun BookingsPage(l:Lang,db:FirebaseFirestore,uid:String,role:Role){CrudPage(l,"الطلبات والحجوزات",db,"bookings",uid,listOf("customerId","providerId","serviceId","equipmentId","date","start","end","status","notes","total","paid","remaining"),"إضافة حجز")}
@Composable private fun InvoicesPage(l:Lang,db:FirebaseFirestore,uid:String){CrudPage(l,"الفواتير",db,"invoices",uid,listOf("number","customerId","service","date","currency","amount","paid","remaining","status","notes"),"إنشاء فاتورة")}
@Composable private fun AccountingPage(l:Lang,db:FirebaseFirestore,uid:String){CrudPage(l,"المحاسبة",db,"transactions",uid,listOf("date","type","category","description","amount","currency","account","reference","paymentStatus"),"إضافة حركة مالية")}
@Composable private fun SubscriptionsPage(l:Lang,db:FirebaseFirestore,uid:String,role:Role){if(role==Role.OWNER)CrudPage(l,"المشتركون والاشتراكات",db,"subscriptions",uid,listOf("userId","plan","status","startDate","endDate","renewal","amount","currency","paymentId"),"تسجيل اشتراك")else CrudPageReadOnly(l,"اشتراكي",db,"subscriptions",uid,listOf("plan","status","startDate","endDate","renewal","amount","currency","paymentId"))}

@Composable private fun OwnerPage(l:Lang,db:FirebaseFirestore){
 var users by remember{mutableStateOf(0)};var subs by remember{mutableStateOf(0)};var revenueTnd by remember{mutableStateOf(0.0)};var revenueFx by remember{mutableStateOf(0.0)};var err by remember{mutableStateOf("")};var show by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
 LaunchedEffect(Unit){try{users=db.collection("users").get().await().size();subs=db.collection("subscriptions").whereEqualTo("status","active").get().await().size();val rows=db.collection("owner_finance").get().await();revenueTnd=rows.documents.filter{it.getString("currency")=="TND"}.sumOf{it.getDouble("amount")?:0.0};revenueFx=rows.documents.filter{it.getString("currency")!="TND"}.sumOf{it.getDouble("amount")?:0.0}}catch(e:Exception){err=e.message?:""}}
 LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("لوحة مالك التطبيق",style=MaterialTheme.typography.headlineSmall);Text("المالك وحده يرى الإيرادات والحسابات البنكية وبيانات المشتركين.")};item{Metric("إجمالي المستخدمين",users.toString())};item{Metric("الاشتراكات النشطة",subs.toString())};item{Metric("إيرادات TND",String.format("%.2f",revenueTnd))};item{Metric("إيرادات العملات الأجنبية",String.format("%.2f",revenueFx))};item{Button(onClick={show=true}){Text("إضافة حركة/حساب مالي للمالك")}};if(err.isNotBlank())item{Text(err,color=MaterialTheme.colorScheme.error)}}
 if(show)DataFormDialog("حساب/حركة مالية للمالك",listOf("accountName","accountType","currency","type","source","amount","balance","date","description"),{data->scope.launch{db.collection("owner_finance").add(data+mapOf("createdAt" to System.currentTimeMillis())).await()};show=false}){show=false}
}
@Composable private fun Metric(a:String,b:String){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(a);Text(b,style=MaterialTheme.typography.titleLarge)}}}

@Composable private fun DocumentsPage(l:Lang,db:FirebaseFirestore,uid:String){
 val context=LocalContext.current;var selected by remember{mutableStateOf<Uri?>(null)};var ocr by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
 fun runOcr(u:Uri){selected=u;busy=true;TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromFilePath(context,u)).addOnSuccessListener{ocr=it.text;busy=false}.addOnFailureListener{ocr="تعذر استخراج النص: ${it.message}";busy=false}}
 val pick=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)runOcr(u)}
 val take=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()){ok->if(ok&&selected!=null)runOcr(selected!!)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("المستندات والمسح",style=MaterialTheme.typography.headlineSmall);Text("التقاط بالكاميرا أو اختيار صورة، ثم استخراج النص. يجب مراجعة النص قبل اعتماده.")
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={pick.launch("image/*")}){Text("اختيار صورة")};Button(onClick={val file=File(context.cacheDir,"scan_${System.currentTimeMillis()}.jpg");selected=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);take.launch(selected!!)}){Text("الكاميرا")}}
  if(busy)CircularProgressIndicator();if(selected!=null)Text("تم التقاط/اختيار المستند");if(ocr.isNotBlank()){OutlinedTextField(ocr,{ocr=it},label={Text("النص المستخرج — راجعه قبل الحفظ")},modifier=Modifier.fillMaxWidth().height(220.dp));Button(onClick={scope.launch{db.collection("documents").add(mapOf("userId" to uid,"text" to ocr,"uri" to selected.toString(),"reviewed" to true,"createdAt" to System.currentTimeMillis())).await()}}){Text("حفظ بعد المراجعة")}}}
}

@Composable private fun ReportsPage(context:Context,l:Lang,db:FirebaseFirestore,uid:String){
 var message by remember{mutableStateOf("")};val scope=rememberCoroutineScope();Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("التقارير وPDF",style=MaterialTheme.typography.headlineSmall);Text("إنشاء تقرير نصي/PDF للحسابات أو المزرعة. العملات تبقى منفصلة.");Button(onClick={scope.launch{try{val tr=db.collection("transactions").whereEqualTo("userId",uid).get().await();val lines=tr.documents.map{d->"${d.getString("date")} | ${d.getString("type")} | ${d.getDouble("amount")?:0.0} ${d.getString("currency")?:""}"};val file=createPdf(context,"Ardhi Farm - Report",lines);shareFile(context,file);message="تم إنشاء التقرير"}catch(e:Exception){message=e.message?:"تعذر إنشاء التقرير"}}}){Text("إنشاء PDF ومشاركته")};if(message.isNotBlank())Text(message)}
}

@Composable private fun SettingsPage(context:Context,l:Lang,onLang:(Lang)->Unit,onLogout:()->Unit,onReloadRole:()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("الإعدادات",style=MaterialTheme.typography.headlineSmall);Text("اللغة");Lang.values().forEach{x->FilterChip(l==x,{onLang(x)},label={Text(x.native)})};Text("الوحدات: m² / ha / m³ / kg / ton / liter");Text("العملات: TND وحسابات العملات الأجنبية منفصلة");Text("الأدوار: شخص، مزارع، مالك معدات، مهني، شركة، محاسب، مالك التطبيق");Button(onClick={sendTestNotification(context)}){Text("اختبار إشعار")};OutlinedButton(onClick=onLogout){Text("تسجيل الخروج")}}
}

@Composable private fun CrudPageReadOnly(l:Lang,title:String,db:FirebaseFirestore,collection:String,uid:String,fields:List<String>){
 var rows by remember{mutableStateOf(emptyList<RowData>())};var error by remember{mutableStateOf("")}
 LaunchedEffect(collection,uid){try{val s=db.collection(collection).whereEqualTo("userId",uid).get().await();rows=s.documents.map{RowData(it.id,it.data)}}catch(e:Exception){error=e.message?:"تعذر التحميل"}}
 Column(Modifier.fillMaxSize().padding(16.dp)){Text(title,style=MaterialTheme.typography.headlineSmall);Text("لا يمكن للمستخدم تعديل الاشتراك؛ التفعيل والدفع يديرهما النظام/المالك.");if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(rows){r->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){fields.forEach{f->if(r.data[f]!=null)Text("$f: ${r.data[f]}")}}}}}}
}

@Composable private fun CrudPage(l:Lang,title:String,db:FirebaseFirestore,collection:String,uid:String,fields:List<String>,button:String){
 val context=LocalContext.current
 var rows by remember{mutableStateOf(emptyList<RowData>())};var show by remember{mutableStateOf(false)};var loading by remember{mutableStateOf(true)};var error by remember{mutableStateOf("")};val scope=rememberCoroutineScope();var refresh by remember{mutableStateOf(0)}
 LaunchedEffect(collection,uid,refresh){loading=true;try{val s=db.collection(collection).whereEqualTo("userId",uid).orderBy("createdAt",Query.Direction.DESCENDING).get().await();rows=s.documents.map{RowData(it.id,it.data)};error=""}catch(e:Exception){error=e.message?:"تعذر التحميل"};loading=false}
 Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(title,style=MaterialTheme.typography.headlineSmall);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){if(collection=="invoices")TextButton(onClick={val lines=rows.map{r->fields.filter{f->r.data[f]!=null}.joinToString(" | "){f->"$f=${r.data[f]}"}};shareFile(context,createPdf(context,"Ardhi Farm - Invoice Report",lines))}){Text("PDF")};Button({show=true}){Text(button)}}};if(loading)LinearProgressIndicator(Modifier.fillMaxWidth());if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(rows){r->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){fields.forEach{f->if(r.data[f]!=null)Text("$f: ${r.data[f]}")};Row{TextButton(onClick={scope.launch{db.collection(collection).document(r.id).delete().await();refresh++}}){Text("حذف")};TextButton(onClick={scope.launch{audit(db,uid,"delete_$collection",mapOf("id" to r.id));refresh++}}){Text("سجل العملية")}}}}}}}
 if(show)DataFormDialog(title,fields,{data->scope.launch{try{db.collection(collection).add(data+mapOf("userId" to uid,"createdAt" to System.currentTimeMillis(),"updatedAt" to System.currentTimeMillis())).await();audit(db,uid,"create_$collection",data);refresh++}catch(e:Exception){error=e.message?:"تعذر الحفظ"}};show=false}){show=false}
}

@Composable private fun DataFormDialog(title:String,fields:List<String>,onSave:(Map<String,Any>)->Unit,onDismiss:()->Unit){var vals by remember{mutableStateOf(fields.associateWith{""})};AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.heightIn(max=500.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){fields.forEach{f->OutlinedTextField(vals[f]?:"",{v->vals=vals.toMutableMap().also{it[f]=v}},label={Text(f)},modifier=Modifier.fillMaxWidth())}}},confirmButton={Button(onClick={onSave(vals.filterValues{it.isNotBlank()}.mapValues{(_,v)->coerce(v)})}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})}
private fun coerce(v:String):Any= v.toDoubleOrNull()?:when(v.lowercase()){"true"->true;"false"->false;else->v}

private suspend fun audit(db:FirebaseFirestore,uid:String,action:String,details:Map<String,Any?>){db.collection("audit").add(mapOf("userId" to uid,"action" to action,"details" to details,"createdAt" to System.currentTimeMillis())).await()}
private fun createPdf(context:Context,title:String,lines:List<String>):File{val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val p=android.graphics.Paint();p.textSize=18f;c.drawText(title,32f,40f,p);p.textSize=11f;var y=65f;lines.take(55).forEach{c.drawText(it.take(90),32f,y,p);y+=14f};doc.finishPage(page);val file=File(context.cacheDir,"ardhi_report_${System.currentTimeMillis()}.pdf");file.outputStream().use{doc.writeTo(it)};doc.close();return file}
private fun shareFile(context:Context,file:File){val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"مشاركة التقرير"))}
private fun sendTestNotification(context:Context){val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;val channel="ardhi";if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(channel,"Ardhi",NotificationManager.IMPORTANCE_DEFAULT));val b=if(Build.VERSION.SDK_INT>=26)android.app.Notification.Builder(context,channel)else android.app.Notification.Builder(context);nm.notify(1001,b.setContentTitle("أرضي – Ardhi Farm").setContentText("إشعار تجريبي").setSmallIcon(android.R.drawable.ic_dialog_info).build())}
