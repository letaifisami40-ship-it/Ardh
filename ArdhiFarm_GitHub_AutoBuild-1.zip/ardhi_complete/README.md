# أرضي – Ardhi Farm — Complete source build

This package is the consolidated Android source for the agreed Ardhi Farm scope: Firebase Auth/Firestore/Storage, roles, farms/fields/activities, fertilizer calculations, equipment and pricing, requests/bookings/work logs/maintenance, invoices, accounting, owner finance, subscriptions/payments, six languages, RTL/LTR, notifications hooks, document capture, PDF generation, ratings and audit history.

## Important
- This is source code, not a falsely-labelled APK. The current execution environment does not contain the Android SDK/Gradle toolchain, so an APK cannot be honestly claimed as built here.
- The supplied `google-services.json` is tied to Firebase project `ardhi-farm` and application id `Com.ardhi.farm`.
- For the owner dashboard, set the corresponding user's `role` field to `owner` in Firestore (or use Firebase custom claims in a production hardening pass). Do not expose an owner registration option to normal users.
- Deploy `firestore.rules` before production testing.
- ML Kit dependency is included for document OCR integration; the app always requires user review before accepting extracted data.
- Android PDF creation uses the platform PDF APIs. Sharing uses Android's standard share intents.
- Real payment gateway integration and official tax filing require the selected payment provider and Tunisian regulatory/API requirements; the app models subscription/payment records but does not invent a gateway connection.
